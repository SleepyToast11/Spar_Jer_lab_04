package Lab04A;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

//welp, good practice anyways
public class Main {
    Person p1 = new Person("joe", 33);
    Person p2 = new Person("bob", 22);
    Person p3 = new Person("jacob", 11);
    Person p4 = new Person("calvin", 55);
    Person p5 = new Person("ralph", 66);
    List<Person> people = Arrays.asList(p1, p2, p3, p4, p5);

}
